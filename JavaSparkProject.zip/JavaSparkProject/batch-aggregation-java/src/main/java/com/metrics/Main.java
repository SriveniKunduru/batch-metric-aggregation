package com.metrics;

import org.apache.spark.sql.*;
import org.apache.spark.sql.types.*;
import java.util.Arrays;
import static org.apache.spark.sql.functions.*;

public class Main {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("Batch Metric Aggregation")
                .master("local[*]")
                .getOrCreate();

        StructType schema = new StructType()
                .add("metric", DataTypes.StringType)
                .add("value", DataTypes.DoubleType)
                .add("timestamp", DataTypes.StringType);

        Row[] rows = new Row[] {
                RowFactory.create("temperature", 88.0, "2022-06-04T12:01:00.000Z"),
                RowFactory.create("temperature", 89.0, "2022-06-04T12:01:30.000Z"),
                RowFactory.create("precipitation", 0.5, "2022-06-04T14:23:32.000Z")
        };

        Dataset<Row> df = spark.createDataFrame(Arrays.asList(rows), schema);
        df = df.withColumn("date", to_date(col("timestamp")));

        Dataset<Row> result = df.groupBy("date", "metric")
                .agg(
                        avg("value").alias("average"),
                        min("value").alias("minimum"),
                        max("value").alias("maximum")
                ).orderBy("date", "metric");

        result.show(false);

        spark.stop();
    }
}
